import sys
import numpy as np
import pandas as pd
path_name = 'C:/Users/M543015/Desktop/OOMS/simulation'
sys.path.append(path_name+"/code")
import natural_progression
import treatment
import create_cohort
import library
ideal_flag = True
if ideal_flag:
    import ideal_screening as scr
else:
    import screening_distribution as scr

drop_noadenoma = True
drop_noprog = True



runs = 1 #factor out the loop entirely and run it just once
cohort_size = []
years_lost_with_screening = []
years_lost_no_screening = []
n_deaths_no_sc = []
n_deaths_sc = []
#This gets confusing. Terminology is explained in a separate document. In short,
# people who have cancer but will die of other causes without a diagnosis (assuming
# no screening) are "unaffected" by their cancer. Those who have an adenoma but
#no cancer when they die are also unaffected. Those who get a diagnosis 
# (assuming no screening) before death are affected by it. Implicit in here is
# the assumption that a patient will not die of CRC without a diagnosis for it.
#The unaffected group does not save or lose life years due to screening or cancer.

#The "affected" group  - identified using the not screening path - are the ones
# where we can save years of life. We can also prevent cancer in a meaningful
#way - meaningful being impactful on life years

#HOWEVER: screening can also remove cancer, prevent cancer, and remove adenomas
# from people who would never be diagnosed with CRC in their lifetime without
# screening. It may be interesting to look at them too, but their numbers are harder
#(For me) to interpret. 
total_pats_adenomas_removed_affected = []
total_pats_dxed_with_cancer_affected = []
total_progressive_adenoma = [] # includes affected and unaffected
total_cancerous_before_death_no_screening = [] #includes affected and unaffected
total_adenomas_removed = [] #includes affected and unaffected
total_pats_dxed_with_cancer = [] #includes affected and unaffected
total_prevented  = [] #includes affected and unaffected
total_die_with_adenoma_no_screening = [] #unaffected contributors - die with adenoma
total_dxed_with_cancer_no_screening= [] #only affected
mean_age_dx = []
median_age_dx = []
mean_age_dx_no_sc = []
median_age_dx_no_sc = []
s_counts_no_sc = []
s_counts = []
up_to_date_rate = []

print(1)
N = 100000 #create a cohort of patient-years that have ID and gender
cohort = create_cohort.Cohort(path_name = path_name, size = N, birth_year = 1960)
#cohort.assign_races()
cohort.get_life_expectancy()# "df.death" is now the life expectancy assuming no cancer and no screening
cohort.remove_pats_who_die_by_50() #  This also updates the cohort attribute size.
cohort_size += [len(cohort.df.ID.unique())]
#get the natural progression of the cancer - without intervention
progression = natural_progression.Adenoma(cohort) #copy the data set
progression.instantiate_adenoma() # this filters down the data set to patient-years with simulated adenoma events; it has location
if drop_noadenoma:
    progression.remove_if_after_death() # remove if the adenoma would happen after simulated non-cancer death
progression.determine_if_cancerous() # assign true or false to "progressive" - will it become cancer?
progression.generate_timescales() # now we have years in each stage; PCT is (total?) time before diagnosis; I think AGT is before stage 1
# Keep only examples that are progressive
# Question: should we further restrict to those who would not get a dx before death? This 
#would skew the adenoma growth time and pre clinical time to shorter values if we did.
# but if never dx-ed, their life isnt affected by it in terms of life years.
#the means are 7 (!) and 2.6. I do this later anyways...
if drop_noprog:
    progression.clean_up_df() #dxed_no_screening is the stage of diagnosis and age_at_dx_no_screening is the age of dx

#now get the screening - only for pats with a progressive adenoma to speed it up
foo1 = progression.adenomadf[["ID","age"]].merge(cohort.df, how = "left", on = "ID", suffixes = ('_tmp',''))
foo1.drop("age_tmp", inplace=True, axis = 1) #now we go back to the patient-year level, but only for those who got cancer
if ideal_flag:
    screening = scr.Screening(foo1)
    screening.generate_first_tests(50) # this flags certain patient years, in the column "type", with test type...the rest are left as NaN
else:
    screening = scr.Screening(foo1, path_name = path_name)
    screening.generate_first_tests()
for i in range(25):#I guess in theory a person could have a fit test each year 50-75
    screening.generate_next_tests() #I'm a little unclear on how the testing schedule works
utd = library.get_up_to_date_years(screening.screeningdf[["ID","age","type"]].copy()) #unclear on this logic
###This is defined to be from age 50 to 75!!
up_to_date_rate += [utd.up_to_date.sum()/len(utd)] #I think these steps are to get a rate for how many people are up to date
# so it seems like this should be = 1 for ideal screening, but it's 0.996918511755307...weird...
final_results = screening.determine_first_positive(progression.adenomadf) #now we have assigned tests results, and filtered down to the patient-years with tests
# I think at this point we should add a uniform survival time scaler
final_results["uniform"] = np.random.uniform(size = len(final_results))



# I think we only test them up to age 75...also it seems like we've filtered down to 1 per person, maybe after 1 positive we stop screening
#with no screening:
final_results["final_dx"] = final_results.dxed_no_screening
final_results["age_at_final_dx"] = final_results.age_at_dx_no_screening
#Replace if screening led to a positive test result

####!!!! I don't think this is right; it should be only if the age at testing is before the symptom-based diagnosis
#indices = final_results.test_result==True
# I am sure there's a cleaner syntax for this but whatever, it works
indices = np.logical_and(final_results.test_result == True, final_results.age_test < final_results.age_at_dx_no_screening)
final_results.loc[indices,"final_dx"] = final_results.loc[indices,"screening_dxed"]
final_results.loc[indices,"age_at_final_dx"] = final_results.loc[indices,"age_test"]
#at this point we just overwrote the no screening data with screening data for some records

final_results["final_dx"] == final_results["dxed_no_screening"]
final_results["age_at_dx_no_screening"] - final_results["age_at_final_dx"]
Nprog_adenoma, underlying_cancer_no_sc, \
adenomas_removed, total_dxed, prevented, \
n_die_with_adenoma_only_no_sc, \
n_dxed_no_sc = library.perform_calculations(final_results)
# there's probably some important stuff I can factor out of those calculations...wait...did generate_timescales simulate death or not?
total_dxed_with_cancer_no_screening += [n_dxed_no_sc]
total_die_with_adenoma_no_screening += [n_die_with_adenoma_only_no_sc]
total_prevented += [prevented]
total_pats_dxed_with_cancer += [total_dxed]
total_adenomas_removed += [adenomas_removed]
total_cancerous_before_death_no_screening += [underlying_cancer_no_sc]
total_progressive_adenoma += [Nprog_adenoma]


ar_affected, \
nwith_affected  = library.calculate_for_affected_group(final_results)

total_pats_adenomas_removed_affected += [ar_affected]
total_pats_dxed_with_cancer_affected += [nwith_affected]
# df1 is for people who were tested under screening, and who would have been diagnosed with cancer before non-cancer death without screening
dfnoscreen = final_results[final_results.age_at_dx_no_screening<final_results.death].copy()
dfnoscreen = treatment.exponential_survival_time(dfnoscreen,'dxed_no_screening') #okay I think this is where we actually simulate cancer death
yl, mean_age, median_age, \
stage_counts, n_deaths = treatment.determine_years_lost(dfnoscreen,'dxed_no_screening','age_at_dx_no_screening') 
years_lost_no_screening += [yl]  #the above step adds "actual_death", which is the minimum of non-cancer death and dx age + survival time
median_age_dx_no_sc +=[median_age]
mean_age_dx_no_sc +=[mean_age]
s_counts_no_sc += stage_counts
n_deaths_no_sc += [n_deaths]
# the next steps do it all over again but under screening
dfscreen = final_results[final_results.age_at_final_dx<final_results.death].copy()
dfscreen = treatment.exponential_survival_time(dfscreen,'final_dx') 
yl, mean_age, median_age, \
stage_counts, n_deaths = treatment.determine_years_lost(dfscreen,'final_dx','age_at_final_dx') 
years_lost_with_screening += [yl]
median_age_dx +=[median_age]
mean_age_dx +=[mean_age]
s_counts += stage_counts
n_deaths_sc += [n_deaths]
#end of former loop


noscreen = treatment.exponential_survival_time(final_results.copy(),'dxed_no_screening')
screened = treatment.exponential_survival_time(final_results.copy(),'final_dx')
treatment.determine_years_lost(noscreen,'dxed_no_screening','age_at_dx_no_screening')
treatment.determine_years_lost(screened,'final_dx','age_at_final_dx')
noscreen["years_lost"] = noscreen["death"] - noscreen["actual_death"]
screened["years_lost"] = screened["death"] - screened["actual_death"]

test = screened[noscreen["years_lost"] < screened["years_lost"]]["final_dx"]
print(test.shape)


screened[noscreen["years_lost"] < screened["years_lost"]][["age_at_dx_no_screening", "age_at_final_dx"]]
screened[noscreen["years_lost"] < screened["years_lost"]][["dxed_no_screening", "final_dx", "survival_time"]]
noscreen[noscreen["years_lost"] < screened["years_lost"]][["dxed_no_screening", "final_dx", "survival_time"]]



#a patient who was diagnosed with an adenoma via screening. what stage would they have been diagnosed without screening, and what's the difference in total years? 
# sample1 = final_results[final_results["final_dx"] == "Adenoma"].sample(n=1)
# id1 = sample1["ID"].iloc[0]
# print(noscreen["actual_death"][final_results["ID"]==id1].iloc[0])
# print(screened["actual_death"][final_results["ID"]==id1].iloc[0])
# final_results[final_results["ID"]==id1].iloc[0]

# (df1a["actual_death"] - df_a["actual_death"])
#a patient diagnosed in stage one with screening who would have been diagnosed in stage 4 without.
# sample2 = final_results[(final_results["dxed_no_screening"] == "SIV") & (final_results["final_dx"] == "SI")].sample(n=1)
# id2 = sample2["ID"].iloc[0]
# (df1a["actual_death"] - df_a["actual_death"])[final_results["ID"]==id2]
#maybe one more scenario is someone who was diagnosed with an adenoma but never would have been diagnosed with cancer





print("Affected Population - those who will get a diagnosis of CRC w/o screening")
print("years lost w screening, ", int(np.mean(years_lost_with_screening)),"plus or minus",\
      int(np.std(years_lost_with_screening)/np.sqrt(runs)) )
print("years lost wo screening, ", int(np.mean(years_lost_no_screening)),"plus or minus",\
      int(np.std(years_lost_no_screening)/np.sqrt(runs)) )
print("N deaths wo screening, ", int(np.mean(n_deaths_no_sc)),"plus or minus",\
      int(np.std(n_deaths_no_sc)/np.sqrt(runs)) )
print("N deaths w screening, ", int(np.mean(n_deaths_sc)),"plus or minus",\
      int(np.std(n_deaths_sc)/np.sqrt(runs)) )
print("Number of patients dxed with cancer if no screening, ", int(np.mean(total_dxed_with_cancer_no_screening)),\
      "plus or minus",int(np.std(total_dxed_with_cancer_no_screening)/np.sqrt(runs)) )
print("Number of patients dxed with cancer - affected group, ", int(np.mean(total_pats_dxed_with_cancer_affected)), \
      "plus or minus",int(np.std(total_pats_dxed_with_cancer_affected)/np.sqrt(runs)) )
print("Number of adenomas caught and removed  - affected group, ",int(np.mean(total_pats_adenomas_removed_affected)), \
      "plus or minus",int(np.std(total_pats_adenomas_removed_affected)/np.sqrt(runs)) ) 



print("")
print("All diagnoses")
print("Median age at dx, screening", int(np.median(median_age_dx)), "plus or minus",\
      int(np.std(median_age_dx)/np.sqrt(runs)))
print("Median age at dx, no screening", int(np.median(median_age_dx_no_sc)), "plus or minus",\
      int(np.std(median_age_dx_no_sc)/np.sqrt(runs)))
print("fraction in each stage, screening",np.sum(s_counts,axis=0)/np.sum(s_counts))
print("fraction in each stage, no screening",np.sum(s_counts_no_sc,axis=0)/np.sum(s_counts_no_sc))

print("")
print("Some overall numbers")
print("Number of patients in cohort", int(np.mean(cohort_size)),"plus or minus",\
      int(np.std(cohort_size)/np.sqrt(runs)) )
print("Total number of pats w. progressive adenomas", int(np.mean(total_progressive_adenoma)),"plus or minus",\
      int(np.std(total_progressive_adenoma)/np.sqrt(runs)) )
print("Number of pats w. underlying adenomas (only), no screening", int(np.mean(total_die_with_adenoma_no_screening)),"plus or minus",\
      int(np.std(total_die_with_adenoma_no_screening)/np.sqrt(runs)) )
print("Number of pats w. underlying cancers, no screening", int(np.mean(total_cancerous_before_death_no_screening)),"plus or minus",\
      int(np.std(total_cancerous_before_death_no_screening)/np.sqrt(runs)) )
print("Number of pats w. prevented cancers, any group", int(np.mean(total_prevented)),"plus or minus",\
      int(np.std(total_prevented)/np.sqrt(runs)) )
print("Number of pats w. diagnoses, any group", int(np.mean(total_pats_dxed_with_cancer)),"plus or minus",\
      int(np.std(total_pats_dxed_with_cancer)/np.sqrt(runs)) )
print("Number of pats w. adenomas removed, any group", int(np.mean(total_adenomas_removed)),"plus or minus",\
      int(np.std(total_adenomas_removed)/np.sqrt(runs)) )
print("Up to date rate, progressive adenoma pop. %.2lf" %(np.mean(up_to_date_rate)),"plus or minus %.2lf"\
      %(np.std(up_to_date_rate)/np.sqrt(runs)) )


