import numpy as np

def generate_log_normal(m,v, N):
    """
    This generates draws from a log normal distribution, i.e. X~ log normal. The value 
    m is the mean of x observed, while v is a parameter we should tune. Then we calculate 
    the mean and variance of the Gaussian distribution for y = ln(x), create draws for y,
    and return x = e^y.
    """
    mean = np.log(m/np.sqrt(1.0+v/m**2.0))
    variance = np.log(1.0+v/m**2.0)
    time = np.random.randn(N)*np.sqrt(variance)+mean
    return(np.exp(time))
    
def create_correlated_indices(N, amount):
    new = np.round(np.arange(N)+np.random.randn(N)*amount).astype(int)
    new[new<0] = np.abs(new[new<0])
    new[new>N-1] = (N-1)-np.abs((N-1)-new[new>N-1])
   # new[new<0] = np.abs(np.random.randn((new<0).sum())*amount)
   # new[new>N-1] = N-np.abs(np.random.randn((new>N-1).sum())*amount)
    return(new)
     
    
class Adenoma:
    
    def __init__(self, cohort):
        self.adenomadf = cohort.df.copy()
        
    def instantiate_adenoma(self):
        """
        Source: Appendix 1, Table 1, J Natl Cancer Inst 2009;101:1412–1422
        The prevalence of adenomas is treated *only* as a function of age here.
        The significance of colon vs rectal adenomas is not treated yet.
        """
        ages = self.adenomadf.age.values

        counts = np.array([0.4,1.3, 2.9, 5.8,13.0,28.2,51.9,88.3,136.7,202.4,279.0,351.7,417.6,442.9])/1e5
        values = np.zeros(100)
        edges = np.arange(len(counts))*5+20
        for i in range(len(edges)-1):
            values[edges[i]:edges[i+1]] = counts[i]
        values[edges[i+1]:] = counts[i+1]
        adenoma = np.where(ages<=99,np.random.rand(len(ages))<values[ages], False )
        loc = np.random.rand(len(ages))
        location = np.where(loc<0.31, "rectum", "colon")
        self.adenomadf["adenoma"] = adenoma
        self.adenomadf["location"] = location
        self.adenomadf = self.adenomadf.loc[self.adenomadf.adenoma].copy()

    def remove_if_after_death(self):
        self.adenomadf = self.adenomadf[self.adenomadf.age<self.adenomadf.death].copy()

    def determine_if_cancerous(self):
        """
        Source: Appendix 1, Table 1, J Natl Cancer Inst 2009;101:1412–1422
        Probability adenoma progresses
        0–45 years: linearly increasing from 0 to 3%
        45–65 years: linearly increasing from 3% to 17%
        65–100 years: linearly decreasing 17% to 13%
        """
        age = self.adenomadf.age.values
        probs = np.where(age<45, 0.03*age/45, np.where(age>65, -0.04/35*age+0.244286, 0.14/20*age-0.285))
        adenomas_progressive = np.random.rand(len(age))<probs
        self.adenomadf["progressive"] = adenomas_progressive
        
    
    def generate_timescales(self): 
        """
        Given mean times as an adenoma, in the various stages, and in the preclinical
        cancerous state, generate times for the duration in each state from log-normal
        distributions. The second param should be tuned/calibrated against some data set.
        Determine stage and age at diagnosis.
        """
        N = self.adenomadf.progressive.sum()
        self.N_progressive = N# some of these may go undetected!
        adenoma_time = 16.4
        stage1 = 2
        # stage2 = 2
        # stage3 = 2
        # stage4 = 2
        # preclinical = 2
        stage2 = 1
        stage3 = 1.5
        stage4 = 0.8
        preclinical = 3.6
        indices = self.adenomadf.progressive == True
        noninvasive_adenoma_times = np.random.exponential(scale = adenoma_time, size = N)
        stage1_times = np.random.exponential(scale = stage1, size = N)
        stage2_times = np.random.exponential(scale = stage2, size = N)
        stage3_times = np.random.exponential(scale = stage3, size = N)
        stage4_times = np.random.exponential(scale = stage4, size = N)
        
        #Create a correlation between adenoma time and the time in each stage
#        indices1 = create_correlated_indices(N, int(N/10))
#        indices2 = create_correlated_indices(N, int(N/10))
#        indices3 = create_correlated_indices(N, int(N/10))
#        indices4 = create_correlated_indices(N, int(N/10))
        self.adenomadf.loc[indices,"AGT"] = noninvasive_adenoma_times
        self.adenomadf.loc[indices,"SI"] = stage1_times#[indices1]
        self.adenomadf.loc[indices,"SII"] =  stage2_times#[indices2]
        self.adenomadf.loc[indices,"SIII"] =  stage3_times#[indices3]
        self.adenomadf.loc[indices,"SIV"] =  stage4_times#[indices4]
        self.adenomadf.loc[indices,"PCT"] = np.random.exponential(scale = preclinical, size = N)
        self.adenomadf["dxed_no_screening"] = "null"
        self.adenomadf.loc[self.adenomadf.SI+self.adenomadf.SII+self.adenomadf.SIII+self.adenomadf.SIV<self.adenomadf.PCT,"dxed_no_screening"] = "SIV"
        self.adenomadf.loc[self.adenomadf.SI+self.adenomadf.SII+self.adenomadf.SIII+self.adenomadf.SIV>self.adenomadf.PCT,"dxed_no_screening"] = "SIV"
        self.adenomadf.loc[self.adenomadf.SI+self.adenomadf.SII+self.adenomadf.SIII>self.adenomadf.PCT,"dxed_no_screening"] = "SIII"
        self.adenomadf.loc[self.adenomadf.SI+self.adenomadf.SII>self.adenomadf.PCT,"dxed_no_screening"] = "SII"
        self.adenomadf.loc[self.adenomadf.SI>self.adenomadf.PCT,"dxed_no_screening"] = "SI"
        self.adenomadf["age_at_dx_no_screening"] = self.adenomadf.PCT+self.adenomadf.AGT+self.adenomadf.age
        
    def clean_up_df(self):
        self.adenomadf = self.adenomadf[((self.adenomadf.progressive == True))].copy()# & 
                                        # (self.adenomadf.age_at_dx_no_screening < self.adenomadf.death))].copy()
        