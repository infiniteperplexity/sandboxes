import numpy as np
import pandas as pd
    

def get_type_of_test(N):
    """ Return N test types. I'm using probabilities based off the the number of 
    each procedure that we have in KP data for this population, restricted to
    first and second tests, and only tests prior to diagnoses. >2008.
    type       P(type)
    colon      0.12
    fit        0.87
    sigmoid    0.01
    """
    type_random = np.random.rand(N)
    test_type = np.array(["fit"]*N,  dtype='<U7')
    test_type[type_random>0.99] = "sigmoid"
    test_type[type_random<0.12] = "colon"       
    return(test_type)
    
def get_type_of_test_given_previous(last_type):
    """ Return N test types. I'm using probabilities based off the the number of 
    each procedure that we have in KP data for this population, restricted to
    first and second tests, and only tests prior to diagnoses. >2008.  
    first_type second_type    P(second type)            
    colon      colon          0.64
               fit            0.34
               sigmoid        0.02
    fit        colon          0.08
               fit            0.91
               sigmoid        0.01
    sigmoid    colon          0.21
               fit            0.76
               sigmoid        0.03
    """
    N = len(last_type)
    test_type = np.array(["fit"]*N,  dtype='<U7')
    type_random = np.random.rand(N)
    test_type[((last_type=="colon") & (type_random<0.64))] = "colon"
    test_type[((last_type=="colon") & (type_random>0.98))] = "sigmoid"
    test_type[((last_type=="sigmoid") & (type_random<0.21))] = "colon"
    test_type[((last_type=="sigmoid") & (type_random>0.97))] = "sigmoid"    
    test_type[((last_type=="fit") & (type_random<0.08))] = "colon"
    test_type[((last_type=="fit") & (type_random>0.99))] = "sigmoid"
    return(test_type)
    
class Screening:
    
    def __init__(self, cohortdf):
        self.screeningdf = cohortdf
        self.N = len(cohortdf.ID.unique())
        self.screeningdf["type"] = np.nan
        
    def generate_first_tests(self, age_at_first_test):
        types = get_type_of_test(self.N)
        times = age_at_first_test+np.zeros(self.N)
        IDS = self.screeningdf["ID"].unique()     
        newdf = pd.DataFrame(data = {"ID":IDS,"age":times, "type":types})
        self.screeningdf = self.screeningdf.merge(newdf, how = "left", on = ["ID","age"])
        self.screeningdf.loc[self.screeningdf.type_x.isnull() & ~self.screeningdf.type_y.isnull(),"type_x"] = \
        self.screeningdf.loc[self.screeningdf.type_x.isnull() & ~self.screeningdf.type_y.isnull(),"type_y"]
        self.screeningdf.rename(columns = {"type_x":"type"}, inplace=True)
        self.screeningdf.drop("type_y", axis =1 , inplace=True)
        
    def generate_next_tests(self):

        last_test_index = self.screeningdf[~self.screeningdf.type.isnull()][['ID',
                                           'age']].groupby(['ID']).idxmax().values.flatten()
        last_test_df = self.screeningdf.loc[last_test_index].copy()
        last_test_type = last_test_df.type.values
        #types = get_type_of_test(self.N)
        types = get_type_of_test_given_previous(last_test_type)
        previous_age = last_test_df.age
        last_test_df["delta"] = 0
        last_test_df.loc[last_test_df.type=="fit","delta"] = 1
        last_test_df.loc[last_test_df.type=="colon","delta"] = 10
        last_test_df.loc[last_test_df.type=="sigmoid","delta"] = 5
        ages = (previous_age+last_test_df.delta).values
        IDS = last_test_df.ID.values
        newdf = pd.DataFrame(data = {"ID":IDS,"age":ages, "type":types})

        newdf[["ID","age"]] = newdf[["ID","age"]].astype(int)
        self.screeningdf = self.screeningdf.merge(newdf, how = "left", on = ["ID","age"])
        self.screeningdf.loc[self.screeningdf.type_x.isnull() & ~self.screeningdf.type_y.isnull(),"type_x"] = \
        self.screeningdf.loc[self.screeningdf.type_x.isnull() & ~self.screeningdf.type_y.isnull(),"type_y"]
        self.screeningdf.rename(columns = {"type_x":"type"}, inplace=True)
        self.screeningdf.drop("type_y", axis =1 , inplace=True)
     
        
    def determine_first_positive(self, adenomadf):
        self.screeningdf = self.screeningdf[~self.screeningdf["type"].isnull()].copy()
        self.screeningdf = self.screeningdf[self.screeningdf.age<76].copy()
        merged = adenomadf.merge(self.screeningdf[["ID","age","type"]], 
                          how = "left", on = "ID", suffixes = ('','_test'))
        ##### Get stage test would catch it at if it were a positive
        merged["years_to_test_from_adenoma"] = merged.age_test-merged.age
        merged["possible_interruption"] = merged.years_to_test_from_adenoma>=0
        merged["screening_dxed"] = "None"
        merged.loc[((merged.possible_interruption) & 
                              (merged.AGT+merged.SI+
                               merged.SII+merged.SIII+
                               merged.SIV<
                               merged.years_to_test_from_adenoma)),"screening_dxed"] = "SIV"
        merged.loc[((merged.possible_interruption) & 
                              (merged.AGT+merged.SI+
                               merged.SII+merged.SIII+
                               merged.SIV>
                               merged.years_to_test_from_adenoma)),"screening_dxed"] = "SIV"
        merged.loc[((merged.possible_interruption) & 
                              (merged.AGT+merged.SI+
                               merged.SII+merged.SIII>
                               merged.years_to_test_from_adenoma)),"screening_dxed"] = "SIII"
        merged.loc[((merged.possible_interruption) & 
                              (merged.AGT+merged.SI+
                               merged.SII>
                               merged.years_to_test_from_adenoma)),"screening_dxed"] = "SII"
        merged.loc[((merged.possible_interruption) & 
                              (merged.AGT+merged.SI>
                               merged.years_to_test_from_adenoma)),"screening_dxed"] = "SI"
        merged.loc[((merged.possible_interruption) & 
                              (merged.AGT>
                               merged.years_to_test_from_adenoma)),"screening_dxed"] = "Adenoma"
        ##### Sensitivity numbers = 1.0-FNR
        FIT_adenoma = 0.12
        FIT_cancer = 0.7
        sigmoid_colon_adenoma = 0.85
        sigmoid_colon_cancer= 0.95
        merged["false_negative_prob"] = 0.0
        merged.loc[((merged.type=="fit") & 
                    (merged.screening_dxed=="Adenoma")), "false_negative_prob"] = 1.0-FIT_adenoma
        merged.loc[((merged.type=="fit") & 
                    ((merged.screening_dxed!="Adenoma") &
                     (merged.screening_dxed!="None"))), "false_negative_prob"] = 1.0-FIT_cancer
        merged.loc[((merged.type=="colon") & 
                    (merged.screening_dxed=="Adenoma")), "false_negative_prob"] = 1.0-sigmoid_colon_adenoma
        merged.loc[((merged.type=="colon") & 
                    ((merged.screening_dxed!="Adenoma") &
                     (merged.screening_dxed!="None"))), "false_negative_prob"] = 1.0-sigmoid_colon_cancer
        merged.loc[((merged.type=="sigmoid") & 
                    (merged.screening_dxed=="Adenoma")), "false_negative_prob"] = 1.0-sigmoid_colon_adenoma
        merged.loc[((merged.type=="sigmoid") & 
                    ((merged.screening_dxed!="Adenoma") &
                     (merged.screening_dxed!="None"))), "false_negative_prob"] = 1.0-sigmoid_colon_cancer
        merged["test_result"] = False
        possible_interruptions = (merged.possible_interruption==True).sum()
        chance = np.random.rand(possible_interruptions)
        merged.loc[merged.possible_interruption==True,"test_result"] = \
        chance >= merged.loc[merged.possible_interruption==True,"false_negative_prob"]
        merged = merged[merged.test_result == True].copy()
        first_age_interrupted = merged[["ID","age","age_test"]].groupby(["ID","age"]).idxmin()
        merged = merged.loc[first_age_interrupted.values.flatten()].copy()
        col1 = adenomadf.columns
        col2 = merged.columns
        join_columns = list(set(col1).intersection(set(col2)))
        adenomadf = merged.merge(adenomadf,how = "outer", on = join_columns)
        return adenomadf