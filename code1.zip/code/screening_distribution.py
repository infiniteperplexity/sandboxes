import numpy as np
import pandas as pd
    
def draw_from_cdf(y,cdf,N):
    """ Given a discretized CDF, draw N points
    from the distribution. This should work for any N, including N = 1, which may
    be necessary for continuous covariates in the proportional hazards model.
    """
    left_edge = y[0:len(y)-1]
    interval = y[1:]-left_edge
    values = np.random.rand(N)
    value_bins = np.searchsorted(cdf[1:len(cdf)-1], values)
    random_from_cdf = left_edge[value_bins]+np.random.rand(N)*interval[value_bins]
    return(random_from_cdf)
    
def draw_from_distribution2(y,f,N):
    """ Given a discretized probability distribution f(y), draw N points
    from the distribution. This should work for any N, including N = 1, which may
    be necessary for continuous covariates in the proportional hazards model.
    """
    interval = y[1]-y[0]
    left_edge = y[0:len(y)-1]
    fp = (f[1:]+f[0:len(f)-1])/2.0
    normed = fp/np.sum(fp*interval)
    cdf = np.cumsum(normed)
    cdf = np.array(cdf)/float(cdf[-1])
    values = np.random.rand(N)
    value_bins = np.searchsorted(cdf, values)
    random_from_cdf = left_edge[value_bins]+np.random.rand(N)*interval
    return(random_from_cdf)
    

def get_type_of_test(times,prob_of_test):
    """ Given a set of times, and a dataframe giving the probability of the various
    types of test, given the time, determine the type of test.
    """
    type_random = np.random.rand(len(times))
    times = np.floor(times)
    test_type = np.array([""]*len(times), dtype='<U7')
    for time in np.unique(times):
        subarray=prob_of_test[prob_of_test.time==time].reset_index()
        indices = np.where(times ==time)[0]
        q = np.where(type_random[indices] <= subarray.loc[0]["probability"])[0]
        test_type[indices[q]] = subarray.loc[0]["first_type"]
        q = np.where(((type_random[indices] <= subarray.loc[1]["probability"]+subarray.loc[0]["probability"]) &
                      (type_random[indices] > subarray.loc[0]["probability"])))[0]
        test_type[indices[q]] = subarray.loc[1]["first_type"]
        q = np.where(((type_random[indices] <= subarray.loc[2]["probability"]+subarray.loc[1]["probability"]+subarray.loc[0]["probability"]) &
                      (type_random[indices] > subarray.loc[1]["probability"]+subarray.loc[0]["probability"])))[0]
        test_type[indices[q]] = subarray.loc[2]["first_type"]          
    return(test_type)
    
class Screening:
    
    def __init__(self, cohortdf, path_name):
        self.path_name = path_name
        self.screeningdf = cohortdf
        self.N = len(cohortdf.ID.unique())
        self.screeningdf["type"] = np.nan
        
    def generate_first_tests(self):
        fit_df = pd.read_csv(self.path_name+'/supplementary_files/'+"p_first_test_time_km.csv")
        y = fit_df["time"].values
        #f = fit_df["probability"].values
        #survival = fit_df["survival"].values
        cdf = fit_df["cdf"].values
        survival = 1.0-cdf
        p_test = 1.0-survival[::-1][0]
        prob_of_test = pd.read_csv(self.path_name+'/supplementary_files/'+"p_first_test_type.csv")
        n_with = np.int(p_test*self.N)
#        times = draw_from_distribution2(y,f,n_with)
        times = draw_from_cdf(y,cdf,n_with)
        times = np.floor(times)
        types = get_type_of_test(times, prob_of_test)
        times = times + 50
        IDS = self.screeningdf["ID"].unique()[np.random.choice(np.arange(self.N), size = n_with,replace=False)]     
        newdf = pd.DataFrame(data = {"ID":IDS,"age":times, "type":types})
        self.screeningdf = self.screeningdf.merge(newdf, how = "left", on = ["ID","age"])
        self.screeningdf.loc[self.screeningdf.type_x.isnull() & ~self.screeningdf.type_y.isnull(),"type_x"] = \
        self.screeningdf.loc[self.screeningdf.type_x.isnull() & ~self.screeningdf.type_y.isnull(),"type_y"]
        self.screeningdf.rename(columns = {"type_x":"type"}, inplace=True)
        self.screeningdf.drop("type_y", axis =1 , inplace=True)
        
    def generate_next_tests(self):
        ##This is not generalizable AT ALL. As we add covariates, each data point with have a different
        ## probability distribution for time to next test and for type of next test:
        ## P(time to next test | x) and P(type of next test | time to next test, x)
        ## where x= type of previous test, age of patient, demographics, etc.
        ## We can't keep binning as Im doing here, with a single covariate, it would be a nightmare. 
        ## We likely need a multinomial logit model for the type of test given covariates, and
        ## for both this and for the P(time | x) model, and efficient way of sampling. since again,
        ## each data point has its own x and therefore its own distribution. One solution (which
        ##may be far from ideal) is to create a set of (y,f(y,x)) points for each x, and use 
        ## draw_from_distribution2(y, f(y,x), N=1). But TBD
        #Inverse transform sampling doesnt seem to be a viable option, BTW.
        fit_df = pd.read_csv(self.path_name+'/supplementary_files/'+"p_next_test_time.csv")
        parameters = pd.read_csv(self.path_name+'/supplementary_files/'+"parameters_next_test_time.csv")
        parameters.set_index("variable",inplace=True)
        prob_of_test = pd.read_csv(self.path_name+'/supplementary_files/'+"p_second_test_type.csv")
        prob_of_test.fillna(0,inplace=True)
        last_test_index = self.screeningdf[~self.screeningdf.type.isnull()][['ID',
                                           'age']].groupby(['ID']).idxmax().values.flatten()
        last_test_df = self.screeningdf.loc[last_test_index].copy()
        factors = [1.0, np.exp(parameters.loc["first_type_colon"].values[0]),\
                   np.exp(parameters.loc["first_type_sigmoid"].values[0])]
        N = last_test_df.type.value_counts()
        y = fit_df["time"].values
        hazard = fit_df["hazard"].values
        cumulative = fit_df["cumulative"].values

        f = hazard*factors[0]*np.exp(-cumulative*factors[0])
        S = np.exp(-cumulative*factors[0])
        p_test = 1.0-S[np.argmin(np.abs(y-10))]
        try:
            n_with = np.int(np.floor(N["fit"]*p_test))
        except:
            n_with = -1
        if n_with>0:
            times = draw_from_distribution2(y,f, n_with)
            times = np.floor(times)
            times[times==0] = 1
            prob_of_testF = prob_of_test[prob_of_test["first_type"]=="fit"].drop("first_type",axis=1).rename(columns={"second_type":"first_type"})
            types = get_type_of_test(times, prob_of_testF)
            indices = np.random.choice(np.arange(N["fit"]), size = n_with,replace=False)
            ages = last_test_df.loc[last_test_df.type=='fit'].age.values[indices]+times
            IDS = last_test_df.loc[last_test_df.type=='fit'].ID.values[indices]
            newdf_fit = pd.DataFrame(data = {"ID":IDS,"age":ages, "type":types})
        else:
            newdf_fit = pd.DataFrame(columns=["ID","age","type"])

        f = hazard*factors[1]*np.exp(-cumulative*factors[1])
        S = np.exp(-cumulative*factors[1])
        p_test = 1.0-S[np.argmin(np.abs(y-10))]
        try:
            n_with = np.int(np.floor(N["colon"]*p_test))
        except:
            n_with = -1
        if n_with>0:
            times = draw_from_distribution2(y,f, n_with)
            times = np.floor(times)
            times[times==0] = 1
            prob_of_testC = prob_of_test[prob_of_test["first_type"]=="colon"].drop("first_type",axis=1).rename(columns={"second_type":"first_type"})
            types = get_type_of_test(times, prob_of_testC)
            indices = np.random.choice(np.arange(N["colon"]), size = n_with,replace=False)
            ages = last_test_df.loc[last_test_df.type=='colon'].age.values[indices]+times
            IDS = last_test_df.loc[last_test_df.type=='colon'].ID.values[indices]
            newdf_colon = pd.DataFrame(data = {"ID":IDS,"age":ages, "type":types})
        else:
            newdf_colon = pd.DataFrame(columns=["ID","age","type"])

        f = hazard*factors[2]*np.exp(-cumulative*factors[2])
        S = np.exp(-cumulative*factors[2])
        p_test = 1.0-S[np.argmin(np.abs(y-10))]
        try:
            n_with=np.int(np.floor(N["sigmoid"]*p_test))
        except:
            n_with = -1
        if n_with>0:
            times = draw_from_distribution2(y,f, n_with)
            times = np.floor(times)
            times[times==0] = 1
            prob_of_testS = prob_of_test[prob_of_test["first_type"]=="sigmoid"].drop("first_type",axis=1).rename(columns={"second_type":"first_type"})
            types = get_type_of_test(times, prob_of_testS)
            indices = np.random.choice(np.arange(N["sigmoid"]), size = n_with,replace=False)
            ages = last_test_df.loc[last_test_df.type=='sigmoid'].age.values[indices]+times
            IDS = last_test_df.loc[last_test_df.type=='sigmoid'].ID.values[indices]
            newdf_sigmoid = pd.DataFrame(data = {"ID":IDS,"age":ages, "type":types})
        else:
            newdf_sigmoid = pd.DataFrame(columns = ["ID","age","type"])
        newdf = pd.concat([newdf_fit,newdf_colon,newdf_sigmoid])
        newdf[["ID","age"]] = newdf[["ID","age"]].astype(int)
        self.screeningdf = self.screeningdf.merge(newdf, how = "left", on = ["ID","age"])
        self.screeningdf.loc[self.screeningdf.type_x.isnull() & ~self.screeningdf.type_y.isnull(),"type_x"] = \
        self.screeningdf.loc[self.screeningdf.type_x.isnull() & ~self.screeningdf.type_y.isnull(),"type_y"]
        self.screeningdf.rename(columns = {"type_x":"type"}, inplace=True)
        self.screeningdf.drop("type_y", axis =1 , inplace=True)
     
        
    def determine_first_positive(self, adenomadf):
        self.screeningdf = self.screeningdf[~self.screeningdf["type"].isnull()].copy()
        self.screeningdf = self.screeningdf[self.screeningdf.age<76].copy()
        merged = adenomadf.merge(self.screeningdf[["ID","age","type"]], 
                          how = "left", on = "ID", suffixes = ('','_test'))
        ##### Get stage test would catch it at if it were a positive
        merged["years_to_test_from_adenoma"] = merged.age_test-merged.age
        merged["possible_interruption"] = merged.years_to_test_from_adenoma>=0
        merged["screening_dxed"] = "None"
        merged.loc[((merged.possible_interruption) & 
                              (merged.AGT+merged.SI+
                               merged.SII+merged.SIII+
                               merged.SIV<
                               merged.years_to_test_from_adenoma)),"screening_dxed"] = "SIV"
        merged.loc[((merged.possible_interruption) & 
                              (merged.AGT+merged.SI+
                               merged.SII+merged.SIII+
                               merged.SIV>
                               merged.years_to_test_from_adenoma)),"screening_dxed"] = "SIV"
        merged.loc[((merged.possible_interruption) & 
                              (merged.AGT+merged.SI+
                               merged.SII+merged.SIII>
                               merged.years_to_test_from_adenoma)),"screening_dxed"] = "SIII"
        merged.loc[((merged.possible_interruption) & 
                              (merged.AGT+merged.SI+
                               merged.SII>
                               merged.years_to_test_from_adenoma)),"screening_dxed"] = "SII"
        merged.loc[((merged.possible_interruption) & 
                              (merged.AGT+merged.SI>
                               merged.years_to_test_from_adenoma)),"screening_dxed"] = "SI"
        merged.loc[((merged.possible_interruption) & 
                              (merged.AGT>
                               merged.years_to_test_from_adenoma)),"screening_dxed"] = "Adenoma"
        ##### Sensitivity numbers = 1.0-FNR
        FIT_adenoma = 0.12
        FIT_cancer = 0.7
        sigmoid_colon_adenoma = 0.85
        sigmoid_colon_cancer= 0.95
        merged["false_negative_prob"] = 0.0
        merged.loc[((merged.type=="fit") & 
                    (merged.screening_dxed=="Adenoma")), "false_negative_prob"] = 1.0-FIT_adenoma
        merged.loc[((merged.type=="fit") & 
                    ((merged.screening_dxed!="Adenoma") &
                     (merged.screening_dxed!="None"))), "false_negative_prob"] = 1.0-FIT_cancer
        merged.loc[((merged.type=="colon") & 
                    (merged.screening_dxed=="Adenoma")), "false_negative_prob"] = 1.0-sigmoid_colon_adenoma
        merged.loc[((merged.type=="colon") & 
                    ((merged.screening_dxed!="Adenoma") &
                     (merged.screening_dxed!="None"))), "false_negative_prob"] = 1.0-sigmoid_colon_cancer
        merged.loc[((merged.type=="sigmoid") & 
                    (merged.screening_dxed=="Adenoma")), "false_negative_prob"] = 1.0-sigmoid_colon_adenoma
        merged.loc[((merged.type=="sigmoid") & 
                    ((merged.screening_dxed!="Adenoma") &
                     (merged.screening_dxed!="None"))), "false_negative_prob"] = 1.0-sigmoid_colon_cancer
        merged["test_result"] = False
        possible_interruptions = (merged.possible_interruption==True).sum()
        chance = np.random.rand(possible_interruptions)
        merged.loc[merged.possible_interruption==True,"test_result"] = \
        chance >= merged.loc[merged.possible_interruption==True,"false_negative_prob"]
        merged = merged[merged.test_result == True].copy()
        first_age_interrupted = merged[["ID","age","age_test"]].groupby(["ID","age"]).idxmin()
        merged = merged.loc[first_age_interrupted.values.flatten()].copy()
        col1 = adenomadf.columns
        col2 = merged.columns
        join_columns = list(set(col1).intersection(set(col2)))
        adenomadf = merged.merge(adenomadf,how = "outer", on = join_columns)
        return adenomadf