import pandas as pd
import numpy as np

def draw_using_cdf(y,cdf,N):
    """ Given a discretized CDF, draw N points
    from the distribution. This should work for any N, including N = 1.
    """
    interval = y[1]-y[0]
    left_edge = y[0:len(y)-1]

    values = np.random.rand(N)
    value_bins = np.searchsorted(cdf, values)
    random_from_cdf = left_edge[value_bins]+np.random.rand(N)*interval
    return(random_from_cdf)

class Cohort:

    def __init__(self, path_name,size, birth_year):
        self.path_name = path_name
        self.size = size
        self.birth_year = birth_year
        ages = np.tile(np.arange(100), self.size)
        IDs = np.repeat(np.arange(self.size), 100)
        genders = np.repeat(np.round(np.random.rand(size)).astype(int),100)
        self.df = pd.concat([pd.Series(ages, name = "age"), 
                             pd.Series(IDs, name = "ID"),
                             pd.Series(genders, name = "gender")], axis = 1)
        
    def get_life_expectancy(self):
        """
        Life expectancy distribution obtained from the cohort life table from SSA - 
        https://www.ssa.gov/oact/NOTES/as120/LifeTables_Body.html
        In these tables, we get the survival function for males and females born
        in given decade. I'm just using 1960 right now, in theory you could use another
        decade if I downloaded all the files for each decade born.
        Using the survival function, get the CDF, then use that to draw from the
        underlying probability distribution.
        """
        filename = self.path_name+'/supplementary_files/'+'cohort_life_table_'+str(self.birth_year)+'_birth_year.csv'
        life_table = pd.read_csv(filename)
        life_table.dropna(inplace=True)
        life_table.lxFemale = life_table.lxFemale.str.replace(',','').astype(float)/1e5
        life_table.lxMale = life_table.lxMale.str.replace(',','').astype(float)/1e5
        life_table['cdfFemale'] = 1.0-life_table.lxFemale
        life_table['cdfMale'] = 1.0-life_table.lxMale

        female_index = self.df[self.df.gender == 1].ID.unique()
        male_index = self.df[self.df.gender == 0].ID.unique()
        n_female = len(female_index)
        n_male = self.size - n_female
        
        female_deaths = draw_using_cdf(life_table.xFemale.values,life_table.cdfFemale.values,n_female)
        male_deaths = draw_using_cdf(life_table.xMale.values,life_table.cdfMale.values,n_male)
        
        
        self.df.loc[self.df.gender == 1, "death"] = np.repeat(female_deaths,100)
        self.df.loc[self.df.gender == 0, "death"] = np.repeat(male_deaths,100)

    def remove_pats_who_die_by_50(self):
        """
        Self explanatory. If the patient dies before screening can be even initiated,
        the screening cannot affect anything. We want to study the group of patients
        whom screening may affect. 
        """
        self.df = self.df[self.df.death>=50].copy()
        self.df.reset_index(inplace=True, drop = True)
        self.size = len(self.df.ID.unique())
    