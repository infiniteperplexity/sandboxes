import numpy as np
import pandas as pd



def exponential_survival_time(df, diagnosis_column):
    """
    Source: http://www.beseengetscreened.com/blog/colon-cancer-stages.php
    If the time to death after diagnosis distribution is an exponential, knowing
    the 5 year survival probability is enough to know the distribution.
    If P(x) = lambda*np.exp(-lambda *x), and the chance of survival past
    5 years is y, then lambda = -np.log(y)/5.0. Python takes the "scale" = 1/lambda.
    SI: 0.94
    SII: 0.82
    SIII: 0.67
    SIV: 0.11
    """
    #Adenomas do not lead to death directly. Set a large survival time for all,
    #then replace the stage entries with smaller numbers.
    df["survival_time"] = np.zeros(len(df))+100
    #lam_A = -np.log(0.94)/5.0
    lam_SI = -np.log(0.94)/5.0
    lam_SII = -np.log(0.82)/5.0
    lam_SIII = -np.log(0.67)/5.0
    lam_SIV = -np.log(0.11)/5.0

    if df["isscreened"]:
        lam_SI = -np.log(0.94)/5.0
        lam_SII = -np.log(0.82)/5.0
        lam_SIII = -np.log(0.67)/5.0
        lam_SIV = -np.log(0.11)/5.0
    else:
        lam_SI = -np.log(0.94)/5.0
        lam_SII = -np.log(0.82)/5.0
        lam_SIII = -np.log(0.67)/5.0
        lam_SIV = -np.log(0.11)/5.0

    #size_A = (df[diagnosis_column]=="Adenoma").sum()
    size_SI = (df[diagnosis_column]=="SI").sum()
    size_SII = (df[diagnosis_column]=="SII").sum()
    size_SIII = (df[diagnosis_column]=="SIII").sum()
    size_SIV = (df[diagnosis_column]=="SIV").sum()

    # Glenn added this to test how much of the "years saved" are due to catching adenomas versus cancer
    # df.loc[(df[diagnosis_column]=="Adenoma"),"survival_time"] = np.random.exponential(scale = 1.0/lam_A, size = size_A)
    
    df.loc[(df[diagnosis_column]=="SI"),"survival_time"] = np.random.exponential(scale = 1.0/lam_SI, size = size_SI)
    df.loc[(df[diagnosis_column]=="SII"),"survival_time"] = np.random.exponential(scale = 1.0/lam_SII, size = size_SII)
    df.loc[(df[diagnosis_column]=="SIII"),"survival_time"] = np.random.exponential(scale = 1.0/lam_SIII, size = size_SIII)
    df.loc[(df[diagnosis_column]=="SIV"),"survival_time"] = np.random.exponential(scale = 1.0/lam_SIV, size = size_SIV)
    

    return(df)


def survival_time(df, diagnosis_column):
    """
    Source: http://www.beseengetscreened.com/blog/colon-cancer-stages.php
    KP data for # of years until mortality given that the patient does not survive for
    5 years after diagnosis, as a function of stage.
    
    Given a diagnosis in a given stage, how long will the patient survive? Either the patient
    dies within 5 years, and they get a specific number, or else they live longer than 
    five years and no specific number is returned. KP data here is incomplete: we do not have a long 
    enough observation window on our patients to know how long they survive after a diagnosis
    past the window of five years. That is, we have censored data. More importantly, though, we do
    not know the cause of death.
    """
    print("???????does this actually get used??????????")
    df["survival_prob_given_stage"] = np.random.rand(len(df))
    df["survival_time"] = np.random.rand(len(df))
    df.loc[df[diagnosis_column] == "Adenoma", "five_year_survival"] = True
    df.loc[df[diagnosis_column]=="SI","five_year_survival"] = \
    df.loc[df[diagnosis_column]=="SI","survival_prob_given_stage"] < 0.94
    df.loc[df[diagnosis_column]=="SII","five_year_survival"] = \
    df.loc[df[diagnosis_column]=="SII","survival_prob_given_stage"] < 0.82
    df.loc[df[diagnosis_column]=="SIII","five_year_survival"] = \
    df.loc[df[diagnosis_column]=="SIII","survival_prob_given_stage"] < 0.67
    df.loc[df[diagnosis_column]=="SIV","five_year_survival"] = \
    df.loc[df[diagnosis_column]=="SIV","survival_prob_given_stage"] < 0.11
    
    #if you survive > 5 years, we assume you will not die from cancer, so just
    # set a large survival time.
    df.loc[df.five_year_survival == True, "survival_time"] = 100
    df.loc[((df[diagnosis_column]=="SI") & (df.five_year_survival==False)),"survival_time"] = \
    df.loc[((df[diagnosis_column]=="SI") & (df.five_year_survival==False)),"survival_time"]*0.2+2.1
    df.loc[((df[diagnosis_column]=="SII") & (df.five_year_survival==False)),"survival_time"] = \
    df.loc[((df[diagnosis_column]=="SII") & (df.five_year_survival==False)),"survival_time"]*0.2+2.0
    df.loc[((df[diagnosis_column]=="SIII") & (df.five_year_survival==False)),"survival_time"] = \
    df.loc[((df[diagnosis_column]=="SIII") & (df.five_year_survival==False)),"survival_time"]*0.2+1.8
    df.loc[((df[diagnosis_column]=="SIV") & (df.five_year_survival==False)),"survival_time"] = \
    df.loc[((df[diagnosis_column]=="SIV") & (df.five_year_survival==False)),"survival_time"]*0.2+1.3
    return(df)
 
    
    
    
def determine_years_lost(df, diagnosis_column, age_at_dx_column):
    df["actual_death"] = np.minimum(df[age_at_dx_column] + df.survival_time, df.death)
    ## A patient can have more than one bout with CRC. Take the one that would lead to the
    ## earliest death date. Note that this assumes the screening pattern would not
    ## change given an early adenoma or CRC dx, which is probably wrong (the pat would
    ## become high risk and be screened more)
    indices = df[["ID","actual_death"]].groupby("ID").idxmin().values.flatten()
    df = df.loc[indices].copy()
    years_lost = (df.death-df.actual_death).sum()
    mean_age_dx = df[df[diagnosis_column]!="Adenoma"][age_at_dx_column].mean()
    median_age_dx = df[df[diagnosis_column]!="Adenoma"][age_at_dx_column].median()


    index = df[df[diagnosis_column]!="Adenoma"][diagnosis_column].value_counts().index.values
    values = df[df[diagnosis_column]!="Adenoma"][diagnosis_column].value_counts().values
    s_counts =[[values[index=="SI"][0],values[index=="SII"][0], \
                 values[index=="SIII"][0], values[index=="SIV"][0]]]
    
    n_deaths = (df.actual_death!=df.death).sum()
    return(years_lost, mean_age_dx, median_age_dx, s_counts, n_deaths)
 
    
    
    
    
    
def survival_time_old(df, diagnosis_column):
    """
    Source: http://www.beseengetscreened.com/blog/colon-cancer-stages.php
    KP data for # of years until mortality given that the patient does not survive for
    5 years after diagnosis, as a function of stage.
    
    Given a diagnosis in a given stage, how long will the patient survive? Either the patient
    dies within 5 years, and they get a specific number, or else they live longer than 
    five years and no specific number is returned. KP data here is incomplete: we do not have a long 
    enough observation window on our patients to know how long they survive after a diagnosis
    past the window of five years. That is, we have censored data. More importantly, though, we do
    not know the cause of death.
    """
    df["survival_prob_given_stage"] = np.random.rand(len(df))
    df["survival_time"] = np.random.rand(len(df))
    df.loc[df[diagnosis_column] == "Adenoma", "five_year_survival"] = True
    df.loc[df[diagnosis_column]=="SI","five_year_survival"] = \
    df.loc[df[diagnosis_column]=="SI","survival_prob_given_stage"] < 0.94
    df.loc[df[diagnosis_column]=="SII","five_year_survival"] = \
    df.loc[df[diagnosis_column]=="SII","survival_prob_given_stage"] < 0.82
    df.loc[df[diagnosis_column]=="SIII","five_year_survival"] = \
    df.loc[df[diagnosis_column]=="SIII","survival_prob_given_stage"] < 0.67
    df.loc[df[diagnosis_column]=="SIV","five_year_survival"] = \
    df.loc[df[diagnosis_column]=="SIV","survival_prob_given_stage"] < 0.11
    
    df.loc[((df[diagnosis_column]=="SI") & (df.five_year_survival==False)),"survival_time"] = \
    df.loc[((df[diagnosis_column]=="SI") & (df.five_year_survival==False)),"survival_time"]*0.2+2.1
    df.loc[((df[diagnosis_column]=="SII") & (df.five_year_survival==False)),"survival_time"] = \
    df.loc[((df[diagnosis_column]=="SII") & (df.five_year_survival==False)),"survival_time"]*0.2+2.0
    df.loc[((df[diagnosis_column]=="SIII") & (df.five_year_survival==False)),"survival_time"] = \
    df.loc[((df[diagnosis_column]=="SIII") & (df.five_year_survival==False)),"survival_time"]*0.2+1.8
    df.loc[((df[diagnosis_column]=="SIV") & (df.five_year_survival==False)),"survival_time"] = \
    df.loc[((df[diagnosis_column]=="SIV") & (df.five_year_survival==False)),"survival_time"]*0.2+1.3
    return(df)



def determine_years_lost_old(df, diagnosis_column, age_at_dx_column):
    df["actual_death"] = df.death
    df.loc[df.five_year_survival==False, "actual_death"] = np.minimum(df[df.five_year_survival==False\
          ][age_at_dx_column] + \
          df[df.five_year_survival==False].survival_time, df[df.five_year_survival==False].death)
    ## A patient can have more than one bout with CRC. Take the one that would lead to the
    ## earliest death date. Note that this assumes the screening pattern would not
    ## change given an early adenoma or CRC dx, which is probably wrong (the pat would
    ## become high risk and be screened more)
    indices = df[["ID","actual_death"]].groupby("ID").idxmin().values.flatten()
    df = df.loc[indices].copy()
    years_lost = (df.death-df.actual_death).sum()
    mean_age_dx = df[df[diagnosis_column]!="Adenoma"][age_at_dx_column].mean()
    median_age_dx = df[df[diagnosis_column]!="Adenoma"][age_at_dx_column].median()


    index = df[df[diagnosis_column]!="Adenoma"][diagnosis_column].value_counts().index.values
    values = df[df[diagnosis_column]!="Adenoma"][diagnosis_column].value_counts().values
    s_counts =[[values[index=="SI"][0],values[index=="SII"][0], \
                 values[index=="SIII"][0], values[index=="SIV"][0]]]
    
    
    return(years_lost, mean_age_dx, median_age_dx, s_counts)