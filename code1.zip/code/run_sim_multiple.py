import sys
import numpy as np
np.random.seed(0)
import pandas as pd
path_name = 'C:/Users/M543015/Desktop/OOMS/simulation'
sys.path.append(path_name+"/code")


import natural_progression
its_flag = True
if its_flag:
    import treatment_its as treatment
else:
    import treatment
import create_cohort
import library
ideal_flag = True
if ideal_flag:
    import ideal_screening as scr
else:
    import screening_distribution as scr

drop_noadenoma = True
drop_noprog = True
fix_latescreen = True

runs = 10
cohort_size = []
years_lost_with_screening = []
years_lost_no_screening = []
n_deaths_no_sc = []
n_deaths_sc = []
#This gets confusing. Terminology is explained in a separate document. In short,
# people who have cancer but will die of other causes without a diagnosis (assuming
# no screening) are "unaffected" by their cancer. Those who have an adenoma but
#no cancer when they die are also unaffected. Those who get a diagnosis 
# (assuming no screening) before death are affected by it. Implicit in here is
# the assumption that a patient will not die of CRC without a diagnosis for it.
#The unaffected group does not save or lose life years due to screening or cancer.

#The "affected" group  - identified using the not screening path - are the ones
# where we can save years of life. We can also prevent cancer in a meaningful
#way - meaningful being impactful on life years

#HOWEVER: screening can also remove cancer, prevent cancer, and remove adenomas
# from people who would never be diagnosed with CRC in their lifetime without
# screening. It may be interesting to look at them too, but their numbers are harder
#(For me) to interpret. 
total_pats_adenomas_removed_affected = []
total_pats_dxed_with_cancer_affected = []
total_progressive_adenoma = [] # includes affected and unaffected
total_cancerous_before_death_no_screening = [] #includes affected and unaffected
total_adenomas_removed = [] #includes affected and unaffected
total_pats_dxed_with_cancer = [] #includes affected and unaffected
total_prevented  = [] #includes affected and unaffected
total_die_with_adenoma_no_screening = [] #unaffected contributors - die with adenoma
total_dxed_with_cancer_no_screening= [] #only affected
mean_age_dx = []
median_age_dx = []
mean_age_dx_no_sc = []
median_age_dx_no_sc = []
s_counts_no_sc = []
s_counts = []
up_to_date_rate = []
for run in range(runs):
    print(run)
    N = 100000 
    cohort = create_cohort.Cohort(path_name = path_name, size = N, birth_year = 1960)
    #cohort.assign_races()
    cohort.get_life_expectancy()# by gender and birth year
    cohort.remove_pats_who_die_by_50() #  This also updates the cohort attribute size.
    cohort_size += [len(cohort.df.ID.unique())]
    #get the natural progression of the cancer - without intervention
    progression = natural_progression.Adenoma(cohort)
    progression.instantiate_adenoma()
    if drop_noadenoma:
        progression.remove_if_after_death()
    progression.determine_if_cancerous()
    progression.generate_timescales()
    # Keep only examples that are progressive
    # Question: should we further restrict to those who would not get a dx before death? This 
    #would skew the adenoma growth time and pre clinical time to shorter values if we did.
    # but if never dx-ed, their life isnt affected by it in terms of life years.
    #the means are 7 (!) and 2.6. I do this later anyways...
    fulldf = progression.adenomadf.copy()
    noeffect = fulldf[fulldf.adenoma == False]
    if drop_noprog:
        progression.clean_up_df()
    
    #now get the screening - only for pats with a progressive adenoma to speed it up
    foo1 = progression.adenomadf[["ID","age"]].merge(cohort.df, how = "left", on = "ID", suffixes = ('_tmp',''))
    foo1.drop("age_tmp", inplace=True, axis = 1)
    if ideal_flag:
        screening = scr.Screening(foo1)
        screening.generate_first_tests(50)
    else:
        screening = scr.Screening(foo1, path_name = path_name)
        screening.generate_first_tests()
    for i in range(25):#I guess in theory a person could have a fit test each year 50-75
        screening.generate_next_tests()
    utd = library.get_up_to_date_years(screening.screeningdf[["ID","age","type"]].copy())
    ###This is defined to be from age 50 to 75!!
    up_to_date_rate += [utd.up_to_date.sum()/len(utd)]
    
    final_results = screening.determine_first_positive(progression.adenomadf)
    final_results["uniform"] = np.random.uniform(size = len(final_results))
    
    #with no screening:
    final_results["final_dx"] = final_results.dxed_no_screening
    final_results["age_at_final_dx"] = final_results.age_at_dx_no_screening
    #Replace if screening led to a positive test result
    # this seems wrong to me!  it should only replace it if the screening result was earlier than age_at_screening_no_dx
    indices = final_results.test_result==True
    if fix_latescreen:
        indices = np.logical_and(final_results.test_result == True, final_results.age_test < final_results.age_at_dx_no_screening)

    final_results.loc[indices,"final_dx"] = final_results.loc[indices,"screening_dxed"]
    final_results.loc[indices,"age_at_final_dx"] = final_results.loc[indices,"age_test"]
    
    
    Nprog_adenoma, underlying_cancer_no_sc, \
    adenomas_removed, total_dxed, prevented, \
    n_die_with_adenoma_only_no_sc, \
    n_dxed_no_sc = library.perform_calculations(final_results)
    
    total_dxed_with_cancer_no_screening += [n_dxed_no_sc]
    total_die_with_adenoma_no_screening += [n_die_with_adenoma_only_no_sc]
    total_prevented += [prevented]
    total_pats_dxed_with_cancer += [total_dxed]
    total_adenomas_removed += [adenomas_removed]
    total_cancerous_before_death_no_screening += [underlying_cancer_no_sc]
    total_progressive_adenoma += [Nprog_adenoma]
    
    
    ar_affected, \
    nwith_affected  = library.calculate_for_affected_group(final_results)
    
    total_pats_adenomas_removed_affected += [ar_affected]
    total_pats_dxed_with_cancer_affected += [nwith_affected]
    
    df1 = final_results[final_results.age_at_dx_no_screening<final_results.death].copy()
    df1 = treatment.exponential_survival_time(df1,'dxed_no_screening')
    yl, mean_age, median_age, \
    stage_counts, n_deaths = treatment.determine_years_lost(df1,'dxed_no_screening','age_at_dx_no_screening') 
    years_lost_no_screening += [yl]
    median_age_dx_no_sc +=[median_age]
    mean_age_dx_no_sc +=[mean_age]
    s_counts_no_sc += stage_counts
    n_deaths_no_sc += [n_deaths]
    
    df = final_results[final_results.age_at_final_dx<final_results.death].copy()
    df = treatment.exponential_survival_time(df,'final_dx')
    yl, mean_age, median_age, \
    stage_counts, n_deaths = treatment.determine_years_lost(df,'final_dx','age_at_final_dx') 
    years_lost_with_screening += [yl]
    median_age_dx +=[median_age]
    mean_age_dx +=[mean_age]
    s_counts += stage_counts
    n_deaths_sc += [n_deaths]



print("Affected Population - those who will get a diagnosis of CRC w/o screening")
print("years lost w screening, ", int(np.mean(years_lost_with_screening)),"plus or minus",\
      int(np.std(years_lost_with_screening)/np.sqrt(runs)) )
print("years lost wo screening, ", int(np.mean(years_lost_no_screening)),"plus or minus",\
      int(np.std(years_lost_no_screening)/np.sqrt(runs)) )
print("N deaths wo screening, ", int(np.mean(n_deaths_no_sc)),"plus or minus",\
      int(np.std(n_deaths_no_sc)/np.sqrt(runs)) )
print("N deaths w screening, ", int(np.mean(n_deaths_sc)),"plus or minus",\
      int(np.std(n_deaths_sc)/np.sqrt(runs)) )
print("Number of patients dxed with cancer if no screening, ", int(np.mean(total_dxed_with_cancer_no_screening)),\
      "plus or minus",int(np.std(total_dxed_with_cancer_no_screening)/np.sqrt(runs)) )
print("Number of patients dxed with cancer - affected group, ", int(np.mean(total_pats_dxed_with_cancer_affected)), \
      "plus or minus",int(np.std(total_pats_dxed_with_cancer_affected)/np.sqrt(runs)) )
print("Number of adenomas caught and removed  - affected group, ",int(np.mean(total_pats_adenomas_removed_affected)), \
      "plus or minus",int(np.std(total_pats_adenomas_removed_affected)/np.sqrt(runs)) ) 



print("")
print("All diagnoses")
print("Median age at dx, screening", int(np.median(median_age_dx)), "plus or minus",\
      int(np.std(median_age_dx)/np.sqrt(runs)))
print("Median age at dx, no screening", int(np.median(median_age_dx_no_sc)), "plus or minus",\
      int(np.std(median_age_dx_no_sc)/np.sqrt(runs)))
print("fraction in each stage, screening",np.sum(s_counts,axis=0)/np.sum(s_counts))
print("fraction in each stage, no screening",np.sum(s_counts_no_sc,axis=0)/np.sum(s_counts_no_sc))

print("")
print("Some overall numbers")
print("Number of patients in cohort", int(np.mean(cohort_size)),"plus or minus",\
      int(np.std(cohort_size)/np.sqrt(runs)) )
print("Total number of pats w. progressive adenomas", int(np.mean(total_progressive_adenoma)),"plus or minus",\
      int(np.std(total_progressive_adenoma)/np.sqrt(runs)) )
print("Number of pats w. underlying adenomas (only), no screening", int(np.mean(total_die_with_adenoma_no_screening)),"plus or minus",\
      int(np.std(total_die_with_adenoma_no_screening)/np.sqrt(runs)) )
print("Number of pats w. underlying cancers, no screening", int(np.mean(total_cancerous_before_death_no_screening)),"plus or minus",\
      int(np.std(total_cancerous_before_death_no_screening)/np.sqrt(runs)) )
print("Number of pats w. prevented cancers, any group", int(np.mean(total_prevented)),"plus or minus",\
      int(np.std(total_prevented)/np.sqrt(runs)) )
print("Number of pats w. diagnoses, any group", int(np.mean(total_pats_dxed_with_cancer)),"plus or minus",\
      int(np.std(total_pats_dxed_with_cancer)/np.sqrt(runs)) )
print("Number of pats w. adenomas removed, any group", int(np.mean(total_adenomas_removed)),"plus or minus",\
      int(np.std(total_adenomas_removed)/np.sqrt(runs)) )
print("Up to date rate, progressive adenoma pop. %.2lf" %(np.mean(up_to_date_rate)),"plus or minus %.2lf"\
      %(np.std(up_to_date_rate)/np.sqrt(runs)) )