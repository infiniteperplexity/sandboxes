import pandas as pd
import numpy as np
"""
Helper functions
"""

def get_up_to_date_years(df):
    """
    Columns expected to be ID, age, and type of test recieved at that age
    """
    df = df[((df.age>=50) & (df.age<=75))].copy()
    ages = pd.DataFrame({"age":np.arange(26)+50})
    IDs = pd.DataFrame({"ID":df.ID.unique()})
    ages['key']=0
    IDs['key']=0
    pat_df = ages.merge(IDs, how = "outer", on = 'key')
    pat_df.drop('key',axis=1,inplace=True)
    pat_df.sort_values(["ID", "age"],inplace = True)
    pat_df.reset_index(inplace = True, drop = True)
    
    df = pat_df.merge(df, how = "left", on = ["ID", "age"])
    df["up_to_date"] = False
    df.loc[df.type == "fit","up_to_date"] = True
    for i in np.arange(10):
        df['up_to_date'] = (((df.shift(i).ID == df.ID) & (df.shift(i).type=='colon'))\
          | df.up_to_date == True)
    for i in np.arange(5):
        df['up_to_date'] = (((df.shift(i).ID == df.ID) & (df.shift(i).type=='sigmoid'))\
          | df.up_to_date == True)
    return(df)

def perform_calculations(final_results):
    #Some people develop cancer so late in life that we would not diagnosis them with it
    #unless we had screening implemented. This counterintuitively means we might know of more
    #cancer diagnoses with screening than without. But the underlying numbers are different. 
    # Screening also reduces the number of cancer diagnoses by preventing cancer, though.
    #People with cancer before death, people diagnosed with cancer, people diagnoses with adenoma.
    
    #Underlying:
    n_pats_w_prog_adenomas = len(final_results.ID.unique())
    final_results["first_cancerous_time"] = final_results.age+final_results.AGT
    n_cancerous_before_death_no_screening = len(final_results[final_results.first_cancerous_time<=final_results.death].ID.unique())
    n_dxed_no_screening = len(final_results[final_results["age_at_dx_no_screening"]<=final_results.death].ID.unique())
    n_adenoma_no_screening = len(final_results[final_results.death-final_results.age<=final_results.AGT].ID.unique())
    cancerous_pats = final_results[final_results.first_cancerous_time<final_results.death].copy()
    prevented = len(cancerous_pats[cancerous_pats.final_dx=="Adenoma"].ID.unique())
    #Detected:
    final_results = final_results[final_results.age_at_final_dx<final_results.death].copy()
    adenomas_removed = len(final_results[final_results.final_dx=="Adenoma"].ID.unique())# this only happens with screening
    n_pats_dxed_with_cancer = len(final_results[final_results.final_dx!="Adenoma"].ID.unique())
    return(n_pats_w_prog_adenomas, n_cancerous_before_death_no_screening, \
           adenomas_removed, n_pats_dxed_with_cancer, prevented, \
           n_adenoma_no_screening, n_dxed_no_screening)



def calculate_for_affected_group(final_results):
    tmp = final_results[final_results["age_at_dx_no_screening"]<=final_results.death].copy()
    adenomas_removed = len(tmp[tmp.final_dx=="Adenoma"].ID.unique())# this only happens with screening
    n_pats_dxed_with_cancer = len(tmp[tmp.final_dx!="Adenoma"].ID.unique())
    return(adenomas_removed, n_pats_dxed_with_cancer)